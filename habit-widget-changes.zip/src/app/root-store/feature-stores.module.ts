import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import {
  LAYOUT_FEATURE_NAME,
  layoutReducer,
} from '../core-ui/layout/store/layout.reducer';
import { LayoutEffects } from '../core-ui/layout/store/layout.effects';
import {
  CONFIG_FEATURE_NAME,
  globalConfigReducer,
} from '../features/config/store/global-config.reducer';
import { GlobalConfigEffects } from '../features/config/store/global-config.effects';
import {
  FOCUS_MODE_FEATURE_KEY,
  focusModeReducer,
} from '../features/focus-mode/store/focus-mode.reducer';
import { IDLE_FEATURE_KEY, idleReducer } from '../features/idle/store/idle.reducer';
import { IdleEffects } from '../features/idle/store/idle.effects';
import { issueProvidersFeature } from '../features/issue/store/issue-provider.reducer';
import { PollToBacklogEffects } from '../features/issue/store/poll-to-backlog.effects';
import { PollIssueUpdatesEffects } from '../features/issue/store/poll-issue-updates.effects';
import {
  METRIC_FEATURE_NAME,
  metricReducer,
} from '../features/metric/store/metric.reducer';
import { NOTE_FEATURE_NAME, noteReducer } from '../features/note/store/note.reducer';
import { NoteEffects } from '../features/note/store/note.effects';
import {
  PROJECT_FEATURE_NAME,
  projectReducer,
} from '../features/project/store/project.reducer';
import { ProjectEffects } from '../features/project/store/project.effects';
import {
  menuTreeFeatureKey,
  menuTreeReducer,
} from '../features/menu-tree/store/menu-tree.reducer';
import {
  SIMPLE_COUNTER_FEATURE_NAME,
  simpleCounterReducer,
} from '../features/simple-counter/store/simple-counter.reducer';
import { SimpleCounterEffects } from '../features/simple-counter/store/simple-counter.effects';
import {
  SECTION_FEATURE_NAME,
  sectionReducer,
} from '../features/section/store/section.reducer';
import { TAG_FEATURE_NAME, tagReducer } from '../features/tag/store/tag.reducer';
import { TagEffects } from '../features/tag/store/tag.effects';
import {
  TASK_REPEAT_CFG_FEATURE_NAME,
  taskRepeatCfgReducer,
} from '../features/task-repeat-cfg/store/task-repeat-cfg.reducer';
import { TaskRepeatCfgEffects } from '../features/task-repeat-cfg/store/task-repeat-cfg.effects';
import { TaskRepeatCleanupEffects } from '../features/task-repeat-cfg/store/task-repeat-cleanup.effects';
import { TaskDueEffects } from '../features/tasks/store/task-due.effects';
import { TASK_FEATURE_NAME, taskReducer } from '../features/tasks/store/task.reducer';
import { TaskInternalEffects } from '../features/tasks/store/task-internal.effects';
import { TaskRelatedModelEffects } from '../features/tasks/store/task-related-model.effects';
import { TaskReminderEffects } from '../features/tasks/store/task-reminder.effects';
import { TaskUiEffects } from '../features/tasks/store/task-ui.effects';
import { RecentlyDeletedEffects } from '../features/tasks/recently-deleted/recently-deleted.effects';
import { ShortSyntaxEffects } from '../features/tasks/store/short-syntax.effects';
import { IS_ELECTRON } from '../app.constants';
import { TaskElectronEffects } from '../features/tasks/store/task-electron.effects';
import { WORK_CONTEXT_FEATURE_NAME } from '../features/work-context/store/work-context.selectors';
import { workContextReducer } from '../features/work-context/store/work-context.reducer';
import { WorkContextEffects } from '../features/work-context/store/work-context.effects';
import { IS_ANDROID_WEB_VIEW } from '../util/is-android-web-view';
import { AndroidEffects } from '../features/android/store/android.effects';
import { AndroidFocusModeEffects } from '../features/android/store/android-focus-mode.effects';
import { AndroidForegroundTrackingEffects } from '../features/android/store/android-foreground-tracking.effects';
import { AndroidSyncBridgeEffects } from '../features/android/store/android-sync-bridge.effects';
import { AndroidWidgetEffects } from '../features/android/store/android-widget.effects';
import { AndroidHabitWidgetEffects } from '../features/android/store/android-habit-widget.effects';
import { AndroidOpenTasksWidgetEffects } from '../features/android/store/android-open-tasks-widget.effects';
import { MobileNotificationEffects } from '../features/mobile/store/mobile-notification.effects';
import { IS_IOS_NATIVE, IS_NATIVE_PLATFORM } from '../util/is-native-platform';
import { IosBackgroundTrackingEffects } from '../features/ios/store/ios-background-tracking.effects';
import { CalendarIntegrationEffects } from '../features/calendar-integration/store/calendar-integration.effects';
import { TimeBlockSyncEffects } from '../features/calendar-integration/time-block/time-block-sync.effects';
import { WorkSessionLogEffects } from '../features/calendar-integration/time-block/work-session-log.effects';
import { ElectronEffects } from '../core/electron/electron.effects';
import { DropboxEffects } from '../imex/sync/dropbox/store/dropbox.effects';
import { FinishDayBeforeCloseEffects } from '../features/finish-day-before-close/finish-day-before-close.effects';
import { JiraIssueEffects } from '../features/issue/providers/jira/jira-issue.effects';
import { OpenProjectEffects } from '../features/issue/providers/open-project/open-project.effects';
import { PluginTimeTrackingEffects } from '../plugins/issue-provider/plugin-time-tracking.effects';
import { PluginFinishDayWorklogEffects } from '../plugins/issue-provider/plugin-finish-day-worklog.effects';
import { ReminderCountdownEffects } from '../features/reminder/store/reminder-countdown.effects';
import { SyncEffects } from '../imex/sync/sync.effects';
import { boardsFeature } from '../features/boards/store/boards.reducer';
import { timeTrackingFeature } from '../features/time-tracking/store/time-tracking.reducer';
import { ArchiveOperationHandlerEffects } from '../op-log/apply/archive-operation-handler.effects';
import { plannerFeature } from '../features/planner/store/planner.reducer';
import { PlannerEffects } from '../features/planner/store/planner.effects';
import { AppStateEffects } from './app-state/app-state.effects';
import { appStateFeature } from './app-state/app-state.reducer';
import { PluginHooksEffects } from '../plugins/plugin-hooks.effects';
import { OperationLogEffects } from '../op-log/capture/operation-log.effects';
import { IssueTwoWaySyncEffects } from '../features/issue/two-way-sync/issue-two-way-sync.effects';
import {
  PLUGIN_USER_DATA_FEATURE_NAME,
  pluginUserDataReducer,
} from '../plugins/store/plugin-user-data.reducer';
import {
  PLUGIN_METADATA_FEATURE_NAME,
  pluginMetadataReducer,
} from '../plugins/store/plugin-metadata.reducer';
import {
  REMINDER_FEATURE_NAME,
  reminderReducer,
} from '../features/reminder/store/reminder.reducer';
import { PluginOAuthLifecycleEffects } from '../plugins/oauth/plugin-oauth-lifecycle.effects';
import { ReducerFailureSnackEffects } from './meta/reducer-failure-snack.effects';
@NgModule({
  declarations: [],
  imports: [
    EffectsModule.forFeature([OperationLogEffects, ReducerFailureSnackEffects]),

    StoreModule.forFeature(appStateFeature),
    EffectsModule.forFeature([AppStateEffects]),

    StoreModule.forFeature(LAYOUT_FEATURE_NAME, layoutReducer),
    EffectsModule.forFeature([LayoutEffects]),

    StoreModule.forFeature(CONFIG_FEATURE_NAME, globalConfigReducer),
    EffectsModule.forFeature([GlobalConfigEffects]),

    StoreModule.forFeature(FOCUS_MODE_FEATURE_KEY, focusModeReducer),
    // FocusModeEffects lazy-loaded in main.ts via requestIdleCallback

    StoreModule.forFeature(IDLE_FEATURE_KEY, idleReducer),
    EffectsModule.forFeature([IdleEffects]),

    StoreModule.forFeature(issueProvidersFeature),
    EffectsModule.forFeature([PollToBacklogEffects, PollIssueUpdatesEffects]),

    StoreModule.forFeature(METRIC_FEATURE_NAME, metricReducer),

    StoreModule.forFeature(NOTE_FEATURE_NAME, noteReducer),
    EffectsModule.forFeature([NoteEffects]),

    StoreModule.forFeature(PROJECT_FEATURE_NAME, projectReducer),
    EffectsModule.forFeature([ProjectEffects]),

    StoreModule.forFeature(menuTreeFeatureKey, menuTreeReducer),

    StoreModule.forFeature(SIMPLE_COUNTER_FEATURE_NAME, simpleCounterReducer),
    EffectsModule.forFeature([SimpleCounterEffects]),

    StoreModule.forFeature(SECTION_FEATURE_NAME, sectionReducer),

    StoreModule.forFeature(TAG_FEATURE_NAME, tagReducer),
    EffectsModule.forFeature([TagEffects]),

    StoreModule.forFeature(TASK_REPEAT_CFG_FEATURE_NAME, taskRepeatCfgReducer),
    EffectsModule.forFeature([TaskRepeatCfgEffects, TaskRepeatCleanupEffects]),

    StoreModule.forFeature(TASK_FEATURE_NAME, taskReducer),
    EffectsModule.forFeature([
      TaskInternalEffects,
      TaskRelatedModelEffects,
      TaskReminderEffects,
      TaskUiEffects,
      RecentlyDeletedEffects,
      ShortSyntaxEffects,
      TaskDueEffects,
      ...(IS_ELECTRON ? [TaskElectronEffects] : []),
    ]),

    StoreModule.forFeature(WORK_CONTEXT_FEATURE_NAME, workContextReducer),
    EffectsModule.forFeature([WorkContextEffects]),

    StoreModule.forFeature(boardsFeature),

    StoreModule.forFeature(timeTrackingFeature),
    EffectsModule.forFeature([ArchiveOperationHandlerEffects]),

    StoreModule.forFeature(plannerFeature),
    EffectsModule.forFeature([PlannerEffects]),

    StoreModule.forFeature(PLUGIN_USER_DATA_FEATURE_NAME, pluginUserDataReducer),
    StoreModule.forFeature(PLUGIN_METADATA_FEATURE_NAME, pluginMetadataReducer),
    StoreModule.forFeature(REMINDER_FEATURE_NAME, reminderReducer),

    // EFFECTS ONLY
    EffectsModule.forFeature([
      ...(IS_ANDROID_WEB_VIEW
        ? [
            AndroidEffects,
            AndroidFocusModeEffects,
            AndroidForegroundTrackingEffects,
            AndroidSyncBridgeEffects,
            AndroidWidgetEffects,
            AndroidHabitWidgetEffects,
            AndroidOpenTasksWidgetEffects,
          ]
        : []),
    ]),
    EffectsModule.forFeature([...(IS_IOS_NATIVE ? [IosBackgroundTrackingEffects] : [])]),
    EffectsModule.forFeature([
      ...(IS_NATIVE_PLATFORM ? [MobileNotificationEffects] : []),
    ]),
    EffectsModule.forFeature([IssueTwoWaySyncEffects]),
    EffectsModule.forFeature([CalendarIntegrationEffects]),
    EffectsModule.forFeature([TimeBlockSyncEffects]),
    EffectsModule.forFeature([WorkSessionLogEffects]),
    EffectsModule.forFeature([ElectronEffects]),
    EffectsModule.forFeature([DropboxEffects]),
    EffectsModule.forFeature([FinishDayBeforeCloseEffects]),
    EffectsModule.forFeature([JiraIssueEffects]),
    EffectsModule.forFeature([OpenProjectEffects]),
    EffectsModule.forFeature([PluginTimeTrackingEffects]),
    EffectsModule.forFeature([PluginFinishDayWorklogEffects]),
    EffectsModule.forFeature([ReminderCountdownEffects]),
    EffectsModule.forFeature([SyncEffects]),
    EffectsModule.forFeature([PluginHooksEffects, PluginOAuthLifecycleEffects]),
  ],
})
export class FeatureStoresModule {}
