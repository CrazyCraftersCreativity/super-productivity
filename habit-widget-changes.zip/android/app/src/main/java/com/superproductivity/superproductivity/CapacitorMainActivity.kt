package com.superproductivity.superproductivity

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.window.SplashScreenView
import android.widget.Toast
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.anggrayudi.storage.SimpleStorageHelper
import com.getcapacitor.BridgeActivity
import com.getcapacitor.WebViewListener
import com.superproductivity.superproductivity.app.LaunchUrlReplayGuard
import com.superproductivity.superproductivity.plugins.NavigationBarPlugin
import com.superproductivity.superproductivity.plugins.SafBridgePlugin
import com.superproductivity.superproductivity.receiver.NotificationActionReceiver
import com.superproductivity.superproductivity.service.BackgroundSyncCredentialStore
import com.superproductivity.superproductivity.service.FocusModeForegroundService
import com.superproductivity.superproductivity.service.ForegroundServiceFailure
import com.superproductivity.superproductivity.service.RemoteTrackingNotificationHelper
import com.superproductivity.superproductivity.service.SyncReminderScheduler
import com.superproductivity.superproductivity.util.printWebViewVersion
import com.superproductivity.superproductivity.webview.ImeWebViewHeight
import com.superproductivity.superproductivity.webview.JavaScriptInterface
import com.superproductivity.superproductivity.webview.NativeInsetShimGate
import com.superproductivity.superproductivity.webview.WebHelper
import com.superproductivity.superproductivity.webview.WebViewBlockActivity
import com.superproductivity.superproductivity.webview.WebViewCompatibilityChecker
import com.superproductivity.superproductivity.webview.WebViewRecovery
import com.superproductivity.superproductivity.widget.NotificationActionQueue
import com.superproductivity.superproductivity.widget.TaskListWidgetProvider
import com.superproductivity.plugins.webdavhttp.WebDavHttpPlugin
import org.json.JSONObject

/**
 * All new Super-Productivity main activity, based on Capacitor to support offline use of the entire application
 */
class CapacitorMainActivity : BridgeActivity() {
    private lateinit var javaScriptInterface: JavaScriptInterface
    private var webViewCompatibility: WebViewCompatibilityChecker.Result? = null
    private var webViewBlocked = false
    private var webViewRecoveryScheduled = false

    // Soft-keyboard workaround: the WebView's resting layout height
    // (e.g. MATCH_PARENT), captured so it can be restored when the keyboard hides.
    // See adjustWebViewHeightForKeyboard.
    private var webViewLayoutHeightDefault: Int? = null

    // Reused scratch for getLocationOnScreen in the keyboard layout listener (hot
    // path) to avoid allocating an IntArray on every pass while the IME is up.
    private val webViewLocationOnScreen = IntArray(2)

    // Status-bar overlap workaround: last value pushed to JS, to dedupe the
    // per-layout-pass listener. -1 = nothing pushed yet.
    // See pushStatusBarOverlap.
    private var lastStatusBarOverlapCssPx: Int = -1

    // Last IME state the geometry diagnostic logged, so the per-layout-pass
    // listener logs once per transition instead of every pass. null = nothing yet.
    // See logImeGeometryOnTransition.
    private var lastLoggedKeyboardOpen: Boolean? = null

    private var isTimerCompleteReceiverRegistered = false
    private var isForegroundServiceFailureReceiverRegistered = false
    private var isWidgetDoneDrainReceiverRegistered = false
    private var isNotificationActionDrainReceiverRegistered = false

    private val storageHelper =
        SimpleStorageHelper(this) // for scoped storage permission management on Android 10+

    private val timerCompleteReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == FocusModeForegroundService.ACTION_TIMER_COMPLETE) {
                val isBreak = intent.getBooleanExtra(FocusModeForegroundService.EXTRA_IS_BREAK, false)
                Log.d("SP_FOCUS", "Timer complete broadcast received, isBreak=$isBreak")
                callJSInterfaceFunctionIfExists("next", "onFocusModeTimerComplete$", isBreak.toString())
            }
        }
    }

    private val widgetDoneDrainReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == TaskListWidgetProvider.ACTION_WIDGET_DONE_DRAIN) {
                // Contentless drain signal: Angular pulls the queued IDs itself via
                // getWidgetDoneQueue(), so there is a single delivery path and no
                // task data crosses the string-interpolated JS bridge.
                callJSInterfaceFunctionIfExists("next", "onWidgetDoneDrainRequest$")
            }
        }
    }

    private val notificationActionDrainReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == NotificationActionReceiver.ACTION_DRAIN) {
                // Contentless: Angular pulls the queued actions itself.
                callJSInterfaceFunctionIfExists("next", "onNotificationActionDrainRequest$")
            }
        }
    }

    private val foregroundServiceFailureReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ForegroundServiceFailure.ACTION) {
                return
            }
            val service = intent.getStringExtra(ForegroundServiceFailure.EXTRA_SERVICE) ?: return
            val reason = intent.getStringExtra(ForegroundServiceFailure.EXTRA_REASON) ?: return
            callJSInterfaceFunctionIfExists(
                "next",
                "onForegroundServiceStartFailed$",
                "{service:${JSONObject.quote(service)},reason:${JSONObject.quote(reason)}}"
            )
        }
    }

    override fun load() {
        val result = try {
            WebViewCompatibilityChecker.evaluate(this)
        } catch (e: Throwable) {
            showWebViewInitFailureOrThrow("WebView compatibility check failed", e)
            return
        }
        webViewCompatibility = result
        if (result.isBlocked) {
            webViewBlocked = true
            WebViewBlockActivity.present(this, result)
            finish()
            return
        }
        try {
            super.load()
        } catch (e: Throwable) {
            showWebViewInitFailureOrThrow("BridgeActivity.load() failed to initialize WebView", e)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Register plugins before calling super.onCreate()
        registerPlugin(SafBridgePlugin::class.java)
        registerPlugin(WebDavHttpPlugin::class.java)
        registerPlugin(NavigationBarPlugin::class.java)

        // On Activity recreation (config change / process death) getIntent() still
        // holds the original launch intent and BridgeActivity.load() replays it
        // through onNewIntent — without the LAUNCHED_FROM_HISTORY flag, so the
        // recents guard in onNewIntent doesn't catch it. A stale VIEW data URI
        // would re-fire appUrlOpen and duplicate the URL scheme task action;
        // clear it (mirrors the savedInstanceState guard for handleIntent below).
        if (savedInstanceState != null) {
            intent?.data = null
        } else if (intent != null &&
            !LaunchUrlReplayGuard.shouldDispatchFreshLaunch(this)
        ) {
            // The system relaunched the task after a package update (#11153).
            intent.data = null
        }
        try {
            super.onCreate(savedInstanceState)
        } catch (e: Throwable) {
            showWebViewInitFailureOrThrow("BridgeActivity.onCreate() failed to initialize WebView", e)
            return
        }
        // A recovery relaunch was scheduled during super.onCreate()/load(); don't
        // fall through to the (now-doomed) bridge.webView null check and re-handle it.
        if (webViewBlocked || webViewRecoveryScheduled) {
            return
        }

        val webView = bridge?.webView
        if (webView == null) {
            showWebViewInitFailure("Bridge or WebView is null after onCreate")
            return
        }
        holdSystemSplashUntilPageVisible()

        try {
            printWebViewVersion(webView)

            // DEBUG ONLY
            if (BuildConfig.DEBUG) {
                Handler(Looper.getMainLooper()).postDelayed({
                    val debugToast = Toast.makeText(this, "DEBUG", Toast.LENGTH_SHORT)
                    debugToast.show()
                    Handler(Looper.getMainLooper()).postDelayed({ debugToast.cancel() }, 100)
                }, 10_000)
                WebView.setWebContentsDebuggingEnabled(true)
            }

            webViewCompatibility?.let {
                if (it.status == WebViewCompatibilityChecker.Status.WARN) {
                    Log.w(
                        "SP-WebView",
                        "WebView version ${it.majorVersion ?: "unknown"} below recommended ${WebViewCompatibilityChecker.RECOMMENDED_CHROMIUM_VERSION}",
                    )
                }
            }

            // Hide the action bar
            supportActionBar?.hide()

            // Initialize JavaScriptInterface
            javaScriptInterface = JavaScriptInterface(this, webView)

            // Initialize WebView
            WebHelper().setupView(webView, false)

            // Inject JavaScriptInterface into Capacitor's WebView
            webView.addJavascriptInterface(
                javaScriptInterface,
                WINDOW_INTERFACE_PROPERTY
            )
            if (BuildConfig.FLAVOR.equals("fdroid")) {
                webView.addJavascriptInterface(
                    javaScriptInterface,
                    WINDOW_PROPERTY_F_DROID
                )
            }
        } catch (e: Throwable) {
            showWebViewInitFailureOrThrow("WebView setup failed", e)
            return
        }

        // We made it past the pre-flight version check and the WebView setup.
        // Persist the detected version so a transient mis-read on a later launch
        // can't lock the user out, and clear any prior user override if healthy.
        WebViewCompatibilityChecker.recordSuccessfulLoad(this, webViewCompatibility?.majorVersion)


        // Remember the WebView's resting layout height (e.g. MATCH_PARENT) so the
        // keyboard workaround can restore it on hide. See
        // adjustWebViewHeightForKeyboard.
        webViewLayoutHeightDefault = bridge?.webView?.layoutParams?.height

        // Handle keyboard visibility changes
        val rootView = findViewById<View>(android.R.id.content)
        rootView.viewTreeObserver.addOnGlobalLayoutListener {
            val rect = Rect()
            rootView.getWindowVisibleDisplayFrame(rect)
            val screenHeight = rootView.rootView.height

            val keypadHeight = screenHeight - rect.bottom
            val isKeyboardOpen = keypadHeight > screenHeight * 0.15
            callJSInterfaceFunctionIfExists(
                "next",
                "isKeyboardShown$",
                if (isKeyboardOpen) "true" else "false"
            )
            adjustWebViewHeightForKeyboard(rect, isKeyboardOpen)
            pushStatusBarOverlap(rect)
            // After the shim, so the log shows the height it applied. See
            // logImeGeometryOnTransition.
            logImeGeometryOnTransition(rect, isKeyboardOpen)
        }

        // Register broadcast receiver for focus mode timer completion
        LocalBroadcastManager.getInstance(this).registerReceiver(
            timerCompleteReceiver,
            IntentFilter(FocusModeForegroundService.ACTION_TIMER_COMPLETE)
        )
        isTimerCompleteReceiverRegistered = true
        LocalBroadcastManager.getInstance(this).registerReceiver(
            foregroundServiceFailureReceiver,
            IntentFilter(ForegroundServiceFailure.ACTION)
        )
        isForegroundServiceFailureReceiverRegistered = true
        LocalBroadcastManager.getInstance(this).registerReceiver(
            widgetDoneDrainReceiver,
            IntentFilter(TaskListWidgetProvider.ACTION_WIDGET_DONE_DRAIN)
        )
        isWidgetDoneDrainReceiverRegistered = true
        LocalBroadcastManager.getInstance(this).registerReceiver(
            notificationActionDrainReceiver,
            IntentFilter(NotificationActionReceiver.ACTION_DRAIN)
        )
        isNotificationActionDrainReceiverRegistered = true

        // Schedule background sync worker if credentials are configured.
        // Off the main thread: the first credential read opens the
        // EncryptedSharedPreferences store (Keystore + Tink keyset setup), and
        // in a WebView app the main thread also runs Chromium's browser side,
        // so blocking it here stalls the page load super.onCreate() just
        // started — on every cold start, sync configured or not. If a JS
        // clear() lands between the read and the schedule, a periodic worker
        // stays scheduled; it is a no-op (it skips without credentials).
        val appContext = applicationContext
        Thread({
            try {
                if (BackgroundSyncCredentialStore.hasAnyCredentials(appContext)) {
                    SyncReminderScheduler.ensureScheduled(appContext)
                }
            } catch (e: Exception) {
                Log.e("CapacitorMainActivity", "Background sync scheduling check failed", e)
            }
        }, "sync-schedule-check").start()

        // Handle initial intent (cold start) only on a fresh launch.
        // On Activity recreation (config change) savedInstanceState is non-null
        // and getIntent() still holds the original reminder/notification Intent —
        // re-running handleIntent() there would replay the same action.
        if (savedInstanceState == null) {
            handleIntent(intent)
        }
    }

    private fun showWebViewInitFailureOrThrow(message: String, error: Throwable) {
        if (!WebViewCompatibilityChecker.isLikelyWebViewInitFailure(error)) {
            throw error
        }
        recoverOrShowWebViewInitFailure(message, error)
    }

    private fun showWebViewInitFailure(message: String, error: Throwable? = null) {
        recoverOrShowWebViewInitFailure(message, error)
    }

    /**
     * WebView init failures are usually transient, and the user's own workaround is
     * to relaunch the app — so attempt that automatically once (via [WebViewRecovery])
     * before surfacing the terminal block screen. [WebViewCompatibilityChecker] caps
     * this at one relaunch per window so a genuinely broken provider still reaches
     * the block screen instead of boot-looping. The [webViewRecoveryScheduled] flag
     * stops Capacitor's multiple onCreate/load() failure checkpoints from each
     * scheduling a relaunch. → issue #7518.
     */
    private fun recoverOrShowWebViewInitFailure(message: String, error: Throwable?) {
        if (webViewBlocked || webViewRecoveryScheduled) {
            return
        }
        if (WebViewCompatibilityChecker.canRetryInitFailure(this)) {
            webViewRecoveryScheduled = true
            Log.w("CapacitorMainActivity", "$message - scheduling one-shot WebView recovery relaunch")
            WebViewRecovery.scheduleRelaunch(this)
            return
        }
        blockForWebViewInitFailure(message, error)
    }

    private fun blockForWebViewInitFailure(message: String, error: Throwable?) {
        if (error == null) {
            Log.e("CapacitorMainActivity", "$message - finishing activity")
        } else {
            Log.e("CapacitorMainActivity", "$message - finishing activity", error)
        }
        // The block screen no longer shows the pre-flight version (it is misleading on
        // this path), so log it — otherwise a user report carries no trace of it at all.
        Log.w("CapacitorMainActivity", "WebView init failure preflight: $webViewCompatibility")
        webViewBlocked = true
        WebViewBlockActivity.present(
            this,
            WebViewCompatibilityChecker.initFailureResult(webViewCompatibility),
        )
        finish()
    }

    override fun onNewIntent(intent: Intent) {
        // A relaunch from recents redelivers the task's base intent. Replaying a
        // VIEW data URI would re-fire Capacitor's appUrlOpen and repeat the URL
        // scheme task action (create-task would add the same task again, syncing
        // a duplicate to all devices), so strip the stale URI. OAuth callback
        // replays are equally unwanted.
        if (intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY != 0) {
            intent.data = null
        }
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** Called by the web app once its bundle has initialised, including after a reload. */
    fun onFrontendReady() {
        // A web-side reload (e.g. language change, PWA update, sync-conflict
        // recovery — all do window.location.reload()) re-runs the bundle and
        // re-enters here, but it also wipes the inline --android-status-bar-overlap
        // off the fresh document. Re-arm the dedupe so the next layout pass
        // re-publishes it; otherwise the unchanged value is skipped and the
        // header overlaps the status bar again on the WebView < 140 / API < 35
        // tail. See pushStatusBarOverlap.
        lastStatusBarOverlapCssPx = -1
    }

    private fun handleIntent(intent: Intent) {
        Log.d("SP_INTENT", "handleIntent action: ${intent.action} type: ${intent.type}")

        // Habits widget refresh button: arm the gate that sends the app back to the home
        // screen once Angular has pushed fresh widget data. No-op for any other intent.
        com.superproductivity.superproductivity.widget.HabitWidgetRefreshGate
            .armIfRequested(this, intent)

        // Handle reminder notification tap
        val reminderTaskId = intent.getStringExtra("REMINDER_TASK_ID")
        if (reminderTaskId != null) {
            // Sanitize to prevent JS injection (only allow alphanumeric, dash, underscore)
            val sanitizedId = reminderTaskId.replace(Regex("[^a-zA-Z0-9_-]"), "")
            Log.d("SP_REMINDER", "Reminder tap: taskId=$sanitizedId")
            // Deadline taps carry their type so the frontend clears the deadline
            // reminder, not the task reminder. Other taps stay a plain id, which
            // keeps them working for a JS bundle that predates the typed form.
            val isDeadline = intent.getStringExtra("REMINDER_TYPE") == "DEADLINE"
            val tapPayload = if (isDeadline) {
                org.json.JSONObject()
                    .put("taskId", sanitizedId)
                    .put("reminderType", "DEADLINE")
                    .toString()
            } else {
                sanitizedId
            }
            // Persist for pull-based retrieval (WebView may not be ready on cold start)
            com.superproductivity.superproductivity.widget.ReminderTapQueue.setTaskId(this, tapPayload)
            // Also try push-based delivery (works on warm start). Both forms only
            // contain the sanitized id and a constant, so they are safe to inline.
            val jsArg = if (isDeadline) tapPayload else "'$sanitizedId'"
            callJSInterfaceFunctionIfExists("next", "onReminderTap$", jsArg)
            intent.removeExtra("REMINDER_TASK_ID")
            intent.removeExtra("REMINDER_TYPE")
            return
        }

        // A relaunch from recents redelivers the base intent: a notification
        // action in it was handled already and must not be queued again.
        val isFromHistory = intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY != 0
        // Tracking/focus buttons are broadcasts now (NotificationActionReceiver).
        // Activity intents with these actions can only come from a notification
        // posted by an older build; handle them the same way (#10683).
        if (!isFromHistory && NotificationActionReceiver.handle(this, intent.action)) {
            return
        }
        // Stop tracking on ANOTHER device (remote tracking presence notification).
        // Stays an Activity intent on purpose (unlock required, see
        // RemoteTrackingNotificationHelper.show), but is persisted: on a cold
        // start the WebView isn't ready to receive a push yet.
        if (!isFromHistory && intent.action == RemoteTrackingNotificationHelper.ACTION_REMOTE_STOP) {
            Log.d("SP_TRACKING", "Remote stop action received from notification")
            NotificationActionQueue.setRemoteStop(this, System.currentTimeMillis())
            callJSInterfaceFunctionIfExists("next", "onNotificationActionDrainRequest$")
            return
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        // Save scoped storage permission on Android 10+
        storageHelper.onSaveInstanceState(outState)
        bridge?.webView?.saveState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        // Restore scoped storage permission on Android 10+
        storageHelper.onRestoreInstanceState(savedInstanceState)
        bridge?.webView?.restoreState(savedInstanceState)
    }

    /**
     * Keeps the Android 12+ system splash up until the WebView shows index.html's
     * boot splash, which looks the same. By default the system removes its splash
     * on the activity's first frame, before the WebView has painted the page, so
     * a few frames of blank background (no logo) showed before the web splash.
     *
     * Taking over the splash's exit leaves it on screen as an overlay while the
     * window keeps drawing underneath, so the WebView can render and report
     * onPageCommitVisible (its first frame with the page's content); only then is
     * the overlay removed. (Withholding the window's first draw instead would also
     * keep the WebView from drawing, so that signal could not arrive.) Page load,
     * a load error, or a 2s cap also release it, so a slow or failing page never
     * leaves the app stuck on the splash. Older Android shows no icon splash.
     */
    private fun holdSystemSplashUntilPageVisible() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        var isPageVisible = false
        var splashView: SplashScreenView? = null
        val handler = Handler(Looper.getMainLooper())
        val release = {
            if (!isPageVisible) {
                isPageVisible = true
                handler.removeCallbacksAndMessages(SPLASH_HOLD_TOKEN)
                splashView?.remove()
                splashView = null
            }
        }
        splashScreen.setOnExitAnimationListener { view ->
            if (isPageVisible) {
                view.remove()
            } else {
                splashView = view
            }
        }
        handler.postAtTime(
            release,
            SPLASH_HOLD_TOKEN,
            SystemClock.uptimeMillis() + SPLASH_HOLD_MAX_MS,
        )
        bridge?.addWebViewListener(object : WebViewListener() {
            override fun onPageCommitVisible(view: WebView?, url: String?) = release()
            override fun onPageLoaded(webView: WebView?) = release()
            override fun onReceivedError(webView: WebView?) = release()
        })
    }

    override fun onPause() {
        super.onPause()
        Log.v("TW", "CapacitorFullscreenActivity: onPause")
        callJSInterfaceFunctionIfExists("next", "onPause$")
    }

    override fun onResume() {
        super.onResume()
        Log.v("TW", "CapacitorFullscreenActivity: onResume")
        callJSInterfaceFunctionIfExists("next", "onResume$")
    }

    /**
     * Whether Capacitor's SystemBars leaves the insets unowned on this device, so
     * our native shims below have to step in. See [NativeInsetShimGate].
     */
    private fun shouldRunNativeInsetShim(): Boolean =
        NativeInsetShimGate.shouldRunShim(
            sdkInt = android.os.Build.VERSION.SDK_INT,
            webViewMajor = NativeInsetShimGate.activeProviderMajor(webViewCompatibility),
        )

    /**
     * One-line IME geometry diagnostic, logged once per keyboard transition.
     *
     * #9316 can only be settled on a reporter's device, and the shim is a strict
     * no-op wherever the window already resizes for the IME — so "the bar looks
     * fixed" cannot by itself tell a working shim from one that never ran. This
     * prints the gate's inputs next to the geometry it decides from, so a test
     * build gives an unambiguous answer.
     *
     * Must be called **after** the shim has had its pass, so `paramsHeight` is
     * what the shim just applied rather than the value it replaced. `target` is
     * recomputed here from the same input, so a pass where the shim bailed on a
     * degenerate frame still reads unambiguously (`target` set, `paramsHeight`
     * unchanged) instead of looking like the gate was off. `webViewHeight` is
     * still the pre-layout measurement — it catches up on the next pass.
     *
     * Silent unless explicitly enabled (`adb shell setprop log.tag.SUPKeyboard
     * DEBUG`), so release builds stay quiet; the transition check comes first to
     * keep the per-layout-pass listener cheap. Geometry and versions only — never
     * user content.
     */
    private fun logImeGeometryOnTransition(rect: Rect, isKeyboardOpen: Boolean) {
        if (lastLoggedKeyboardOpen == isKeyboardOpen) return
        lastLoggedKeyboardOpen = isKeyboardOpen
        if (!Log.isLoggable("SUPKeyboard", Log.DEBUG)) return
        val webView = bridge?.webView ?: return
        webView.getLocationOnScreen(webViewLocationOnScreen)
        Log.d(
            "SUPKeyboard",
            "ime=$isKeyboardOpen shim=${shouldRunNativeInsetShim()} " +
                "sdk=${android.os.Build.VERSION.SDK_INT} " +
                "wvMajor=${NativeInsetShimGate.activeProviderMajor(webViewCompatibility)} " +
                "(raw=${webViewCompatibility?.majorVersion} src=${webViewCompatibility?.source}) " +
                "rectBottom=${rect.bottom} webViewTop=${webViewLocationOnScreen[1]} " +
                "target=${
                    ImeWebViewHeight.targetHeight(rect.bottom, webViewLocationOnScreen[1])
                } " +
                "webViewHeight=${webView.height} paramsHeight=${webView.layoutParams?.height}"
        )
    }

    /**
     * Soft-keyboard fallback for the add-task bar sitting behind the keyboard
     * (#8508 follow-up on Android 9 / API 28; #9316 on API 34 + WebView 124/126).
     *
     * Context: Android edge-to-edge inset handling is owned by Capacitor's
     * built-in SystemBars now (the `@capawesome` edge-to-edge plugin was removed).
     * Up to Capacitor 8.5.1 SystemBars only padded for the IME on **WebView >= 140**
     * (passthrough) or **API >= 35**; outside that it applied nothing, the window
     * does NOT resize for the IME, and the `position: fixed` add-task bar sat
     * behind the keyboard. This shim covers exactly that gap — see
     * [NativeInsetShimGate] for why the gate is the complement of SystemBars'
     * two ownership branches. From 8.5.2 SystemBars pads the DecorView for the IME
     * on every API level, so in the gated band this now measures a WebView that is
     * already at the keyboard top and writes the height it already has (kept as a
     * fallback; see [NativeInsetShimGate]).
     *
     * We must NOT correct this via `bottomMargin` or `padding` (a margin writer
     * fights whatever owns the insets, and WebView padding does not move the web
     * layout viewport). Instead, while the keyboard is up we set an explicit
     * WebView **layout height** (to the keyboard top) and restore the resting
     * height ([webViewLayoutHeightDefault], e.g. MATCH_PARENT) on hide. Shrinking
     * the view shrinks the web layout viewport, so the existing CSS resolves the
     * bar above the keyboard with no web-side keyboard-height math (avoiding the
     * reverted #8295 fallback). The target (`rect.bottom − webViewTop`) is read
     * from `getWindowVisibleDisplayFrame` and does not depend on the WebView's
     * own height, so it is stable across passes — no feedback loop.
     *
     * That absolute target is also what makes this **resize-detecting**, the
     * hard requirement #8508 left behind: on a device where the window already
     * shrank for the IME, the WebView bottom is already at `rect.bottom`, so the
     * computed height equals the one in effect. The write still happens once
     * (MATCH_PARENT never equals a px target) but changes nothing visible, so it
     * cannot re-create the squashed-WebView regression the way the reverted
     * delta-based inset did. See docs/android-edge-to-edge-keyboard.md.
     */
    private fun adjustWebViewHeightForKeyboard(rect: Rect, isKeyboardOpen: Boolean) {
        if (!shouldRunNativeInsetShim()) return
        val webView = bridge?.webView ?: return
        val params = webView.layoutParams ?: return
        // Ignore stale/pre-layout geometry so the height is not set from a bad frame.
        if (isKeyboardOpen && webView.height == 0) return

        val targetHeight: Int
        if (isKeyboardOpen) {
            webView.getLocationOnScreen(webViewLocationOnScreen)
            // Absolute target, never a delta — see ImeWebViewHeight for why that is
            // what keeps this from re-creating #8508. null = degenerate/transient
            // frame; keep the current height until a sane value appears, or the
            // height==0 check above would latch and stop recomputing.
            targetHeight = ImeWebViewHeight.targetHeight(
                rectBottom = rect.bottom,
                webViewTop = webViewLocationOnScreen[1],
            ) ?: return
        } else {
            targetHeight = webViewLayoutHeightDefault ?: ViewGroup.LayoutParams.MATCH_PARENT
        }

        if (params.height == targetHeight) return
        params.height = targetHeight
        webView.layoutParams = params
    }

    /**
     * Status-bar overlap workaround for the web header drawing BEHIND the status
     * bar on the WebView < 140 tail (#8508 / #8283 follow-up, Android 9 / API 28;
     * reads 0 and self-disables where the WebView is already inset).
     *
     * Edge-to-edge insets are owned by Capacitor's built-in SystemBars now. On
     * **WebView >= 140** the WebView's own `env(safe-area-inset-*)` is correct and
     * SystemBars mirrors it into `--safe-area-inset-*` (passthrough). Up to
     * Capacitor 8.5.1, on the **WebView < 140 / API < 35** tail nothing inset the
     * WebView: it extended under the status bar while `env(safe-area-inset-top)`
     * resolved to 0 (old WebViews map only display cutouts into safe-area insets,
     * not the status bar) — so the web side had no top inset and content
     * overlapped the status bar. From 8.5.2 SystemBars pads the DecorView for the
     * status bar there too, so this measures 0 (see below) and stays inert.
     *
     * We measure the overlap natively and publish it as the `--android-status-bar-
     * overlap` CSS var, which the web side folds into `--safe-area-top` via
     * `var(--android-status-bar-overlap, var(--safe-area-inset-top, env(...)))`.
     * The overlap is how much of the status bar covers the WebView: `rect.top`
     * (top of the visible display frame = status-bar height, reliable on API 28,
     * the same frame the keyboard path uses) minus the WebView's top on screen
     * (`getLocationOnScreen`: 0 when edge-to-edge, == status-bar height once
     * inset). So it is the status-bar height when the WebView is NOT inset and 0
     * once it is — no insets are added together. Physical px → CSS px via display
     * density; deduped so the per-layout listener does not spam evaluateJavascript.
     *
     * Shares [NativeInsetShimGate] with the keyboard shim. Only where SystemBars
     * leaves the insets unowned do we publish this override; elsewhere CSS falls
     * back to SystemBars / env(). Giving the measurement precedence prevents
     * SystemBars' injected 0px from shadowing it on API < 35 / WebView < 140.
     */
    private fun pushStatusBarOverlap(rect: Rect) {
        if (!shouldRunNativeInsetShim()) return
        if (!::javaScriptInterface.isInitialized) return
        val webView = bridge?.webView ?: return
        webView.getLocationOnScreen(webViewLocationOnScreen)
        val overlapPx = (rect.top - webViewLocationOnScreen[1]).coerceAtLeast(0)
        val density = resources.displayMetrics.density
        val overlapCssPx = if (density > 0f) Math.round(overlapPx / density) else overlapPx
        if (overlapCssPx == lastStatusBarOverlapCssPx) return
        lastStatusBarOverlapCssPx = overlapCssPx
        javaScriptInterface.callJavaScriptFunction(
            "document.documentElement.style.setProperty(" +
                "'--android-status-bar-overlap','${overlapCssPx}px')"
        )
        if (BuildConfig.DEBUG) {
            Log.d(
                "SUPKeyboard",
                "statusBarOverlap -> ${overlapCssPx}px (rectTop=${rect.top} wvTop=${webViewLocationOnScreen[1]})"
            )
        }
    }

    private fun callJSInterfaceFunctionIfExists(
        fnName: String,
        objectPath: String,
        fnParam: String = ""
    ) {
        if (!::javaScriptInterface.isInitialized) {
            Log.w("CapacitorMainActivity", "javaScriptInterface not initialized yet. Skipping JS call.")
            return
        }
        val fnFullName =
            "window.${FullscreenActivity.WINDOW_INTERFACE_PROPERTY}.$objectPath.$fnName"
        val fullObjectPath = "window.${FullscreenActivity.WINDOW_INTERFACE_PROPERTY}.$objectPath"
        javaScriptInterface.callJavaScriptFunction("if($fullObjectPath && $fnFullName)$fnFullName($fnParam)")
    }


    override fun onDestroy() {
        if (isTimerCompleteReceiverRegistered) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(timerCompleteReceiver)
            isTimerCompleteReceiverRegistered = false
        }
        if (isForegroundServiceFailureReceiverRegistered) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(
                foregroundServiceFailureReceiver
            )
            isForegroundServiceFailureReceiverRegistered = false
        }
        if (isWidgetDoneDrainReceiverRegistered) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(widgetDoneDrainReceiver)
            isWidgetDoneDrainReceiverRegistered = false
        }
        if (isNotificationActionDrainReceiverRegistered) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(
                notificationActionDrainReceiver
            )
            isNotificationActionDrainReceiverRegistered = false
        }
        super.onDestroy()
    }

    companion object {
        const val WINDOW_INTERFACE_PROPERTY: String = "SUPAndroid"
        const val WINDOW_PROPERTY_F_DROID: String = "SUPFDroid"
        private const val SPLASH_HOLD_MAX_MS = 2_000L
        private val SPLASH_HOLD_TOKEN = Any()
    }
}
